---
title: Definition of Common Rocketry Terms
subtitle: Prepared for Endeavour Rocketry Team
author:
  - Jasper Day
  - Fergus Wilson
---

Rocketry is a lot of fun, but it comes with a dense thicket of technical jargon to wade through. These are some common rocketry terms which we wish someone would have explained to us when we started out.
